# ExoAnchor Smoke Test Record

This is a blank template, not a completed test report.

## Environment

- Date:
- Tester:
- Source commit:
- Firmware version and track:
- Board model and chip revision:
- ESP-IDF version:
- Host OS and browser:

Do not publish credentials or private device identifiers in a shared report.

## Results

Use PASS, FAIL, NOT RUN, or N/A. Explain failures and N/A results. Keep NOT RUN until a check is actually performed.

| Check | Expected result | Status | Evidence or reason |
| --- | --- | --- | --- |
| Host repository gate | `./scripts/check-all.sh` exits successfully | NOT RUN | |
| Ethernet | Board obtains an address | NOT RUN | |
| Dashboard | `http://<board-ip>/` loads | NOT RUN | |
| KVM video | `/kvm` shows target display | NOT RUN | |
| Keyboard | One harmless character appears in an approved test field | NOT RUN | |
| Mouse | Pointer moves in an approved test session | NOT RUN | |
| Settings | `/settings` loads without saving changes | NOT RUN | |

Only perform input checks on a target you are authorized to control. This template does not request power, reset, flashing, or EEPROM actions. Host checks do not establish hardware readiness.

## Follow-up

- Failed check and reproduction steps:
- Expected vs. actual behavior:
- Sanitized log or screenshot link:
- Next action:

Prepared with AI assistance. No tests have been executed in this template.
