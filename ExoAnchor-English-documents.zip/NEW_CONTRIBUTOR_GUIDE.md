# ExoAnchor: New Contributor Guide

ExoAnchor is an open-source ESP32-P4 remote KVM project. It provides screen access and keyboard/mouse input over an independent network path. The embedded Agent and external MCP controller are optional.

### Start here

- `device/ESP32P4/boards/`: board profiles and validation status.
- `device/ESP32P4/firmware/`: independent Stable and Dev firmware trees.
- `docs/`: usage and reproduction documentation.
- `integrations/exoanchor-mcp/`: optional external MCP controller.
- `scripts/`: repository checks.

### Checklist

- [ ] Read the project overview and firmware index linked below.
- [ ] For hardware work, identify the physical board, chip revision, and required ESP-IDF version.
- [ ] Keep generated build directories and sdkconfig files separate for each board.
- [ ] Start with documentation, a small fix, or a test case on a separate branch.
- [ ] Run relevant checks and record their results. The complete host-only gate is `./scripts/check-all.sh` from the repository root.
- [ ] Keep host checks separate from hardware validation; mark unexecuted tests as NOT RUN.

Stable provides pure KVM; Dev includes the embedded Agent. Do not infer the current firmware version from its directory name alone. Follow the board-specific official guide for flashing; this checklist is not a flashing procedure.

Use the [test record template](SMOKE_TEST_TEMPLATE.md) to record conditions and observations.

## References

- [Project overview](https://github.com/wxffxx/ExoAnchor/blob/main/README_zh.md)
- [Firmware index](https://github.com/wxffxx/ExoAnchor/blob/main/device/ESP32P4/firmware/README.md)
- [Board matrix](https://github.com/wxffxx/ExoAnchor/blob/main/device/ESP32P4/boards/IMPLEMENTATION_PROFILES_zh.md)

Prepared with AI assistance from the upstream documentation. No firmware build or hardware test is claimed by this guide.
